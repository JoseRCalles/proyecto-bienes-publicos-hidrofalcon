<?php
// C:\wamp64\www\systemaHidrofalcon\backend\get-asset-count.php

header('Content-Type: application/json'); // Aseguramos que la respuesta sea JSON

require_once __DIR__ . '/../connect/connect.php'; // Ajusta la ruta a tu archivo de conexión

$response = [
    'success' => false,
    'count' => 0, // Inicializamos el conteo en 0
    'message' => ''
];

// Verificación de conexión
if (!isset($conexion) || $conexion->connect_error) {
    $response['message'] = 'Error de conexión a la base de datos: ' . ($conexion->connect_error ?? 'Desconocido');
    echo json_encode($response);
    exit;
}

try {
    // Consulta SQL para contar las filas en la tabla 'activo'
    $sql = "SELECT COUNT(*) AS total_assets FROM activo";
    
    $result = $conexion->query($sql);

    if ($result) {
        $row = $result->fetch_assoc();
        $response['success'] = true;
        $response['count'] = (int)$row['total_assets']; // Convertimos a entero
    } else {
        throw new Exception("Error al ejecutar la consulta de conteo: " . $conexion->error);
    }

} catch (Exception $e) {
    $response['message'] = $e->getMessage();
} finally {
    // Cerramos la conexión
    if (isset($conexion) && $conexion instanceof mysqli) {
        $conexion->close();
    }
}

echo json_encode($response); // Devolvemos el resultado en formato JSON
?>