<?php

header('Content-Type: application/json');

require '../connect/connect.php';

function obtenerPreguntasSeguridad(mysqli $conexion, int $id_usuario): string {
    $response = [];

    // Consulta para obtener los id_pregunta de la tabla resp_seguridad
    $sql = "SELECT id_pregunta FROM resp_seguridad WHERE id_usuario = ?";
    $stmt = $conexion->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("i", $id_usuario);
        $stmt->execute();
        $result = $stmt->get_result();

        $id_preguntas = [];
        while ($row = $result->fetch_assoc()) {
            $id_preguntas[] = $row['id_pregunta'];
        }
        $stmt->close();

        // Si hay preguntas asociadas, buscar sus detalles en preg_seguridad usando la columna correcta (id)
        if (!empty($id_preguntas)) {
            $placeholders = implode(',', array_fill(0, count($id_preguntas), '?'));
            $sqlPreguntas = "SELECT id, pregunta FROM preg_seguridad WHERE id IN ($placeholders)";
            $stmtPreguntas = $conexion->prepare($sqlPreguntas);

            if ($stmtPreguntas) {
                // Vincular parámetros dinámicamente
                $types = str_repeat('i', count($id_preguntas));
                $stmtPreguntas->bind_param($types, ...$id_preguntas);
                $stmtPreguntas->execute();
                $resultPreguntas = $stmtPreguntas->get_result();

                while ($rowPregunta = $resultPreguntas->fetch_assoc()) {
                    $response[] = $rowPregunta;
                }
                $stmtPreguntas->close();
            } else {
                $response = ['error' => "Error en la consulta SQL (preg_seguridad): " . $conexion->error];
            }
        } else {
            $response = ['error' => 'No se encontraron preguntas de seguridad para este usuario.'];
        }
    } else {
        $response = ['error' => "Error en la consulta SQL (resp_seguridad): " . $conexion->error];
    }

    return json_encode($response, JSON_PRETTY_PRINT);
}

// Corrección: ahora usa POST correctamente
if (isset($_POST['id_usuario'])) {
    $id_usuario = intval($_POST['id_usuario']); // Corrección aquí
    echo obtenerPreguntasSeguridad($conexion, $id_usuario);
} else {
    echo json_encode(['error' => 'Se requiere el id_usuario.'], JSON_PRETTY_PRINT);
}

?>
