<?php
// C:\wamp64\www\systemaHidrofalcon\backend\get-estatus-data.php

header('Content-Type: application/json'); // ¡Es crucial responder con JSON!

// Ruta a tu archivo de conexión a la base de datos
// Ajusta la ruta si este archivo se mueve
require_once __DIR__ . '/../connect/connect.php'; 

$response = [
    'success' => false,
    'data' => [],
    'message' => ''
];

// Verificar la conexión a la base de datos
if (!isset($conexion) || $conexion->connect_error) {
    $response['message'] = 'Error: No se pudo establecer la conexión a la base de datos.';
    echo json_encode($response);
    exit;
}

try {
    // Consulta para obtener los ID y nombres de los estatus
    // Asegúrate de que los nombres de las columnas 'id' y 'nombre_estatus' coincidan con tu tabla 'estatus'
    $sql = "SELECT id, estatus FROM estatus ORDER BY estatus ASC";
    $result = $conexion->query($sql);

    if ($result) {
        $estatus_list = [];
        while ($row = $result->fetch_assoc()) {
            $estatus_list[] = [
                'id' => $row['id'],
                'nombre' => $row['estatus'] // Usamos 'nombre' para la clave JSON
            ];
        }
        $response['success'] = true;
        $response['data'] = $estatus_list;
        $result->free(); // Libera el conjunto de resultados
    } else {
        throw new Exception("Error al obtener estatus de la base de datos: " . $conexion->error);
    }

} catch (Exception $e) {
    $response['message'] = $e->getMessage();
} finally {
    // Es buena práctica cerrar la conexión cuando ya no se necesita, especialmente en un endpoint AJAX
    if (isset($conexion) && $conexion instanceof mysqli) {
        $conexion->close();
    }
}

echo json_encode($response); // Envía la respuesta JSON al cliente
?>