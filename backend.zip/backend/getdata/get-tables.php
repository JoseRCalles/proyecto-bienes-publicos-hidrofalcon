<?php
header('Content-Type: application/json');

// Ensure you have a 'conexionect.php' file that establishes your MySQLi conexionection
// and stores it in a variable like $conexion.
require_once '../connect/connect.php'; 

// Check if the conexionection was successful
if (!$conexion) {
    echo json_encode([
        'success' => false,
        'message' => 'Error de conexión a la base de datos.'
    ]);
    exit();
}

$search = isset($_GET['search']) ? $_GET['search'] : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10; // Default a 10 items per page

$offset = ($page - 1) * $limit;

try {
    // 1. Obtener el total de registros (para la paginación)
    $countQuery = "SELECT COUNT(*) FROM activo WHERE 1"; // Adjust your table and conditions
    $params = [];
    $types = ''; // String to hold parameter types for bind_param

    if (!empty($search)) {
        // Adjust your search fields
        $countQuery .= " AND (descripcion LIKE ? OR serial LIKE ? OR custodio LIKE ?)"; 
        $params[] = '%' . $search . '%';
        $params[] = '%' . $search . '%';
        $params[] = '%' . $search . '%';
        $types .= 'sss'; // 's' for string, 3 times for 3 parameters
    }
    
    $stmtCount = mysqli_prepare($conexion, $countQuery);
    if ($stmtCount === false) {
        throw new Exception("Error al preparar la consulta de conteo: " . mysqli_error($conexion));
    }
    
    if (!empty($params)) {
        mysqli_stmt_bind_param($stmtCount, $types, ...$params);
    }
    
    mysqli_stmt_execute($stmtCount);
    mysqli_stmt_bind_result($stmtCount, $totalProperties);
    mysqli_stmt_fetch($stmtCount);
    mysqli_stmt_close($stmtCount);

    // 2. Obtener los registros para la página actual
    $dataQuery = "SELECT * FROM activo WHERE 1"; // Adjust your tables and joins if necessary
    $params = []; // Reset parameters for the data query
    $types = ''; // Reset types for the data query

    if (!empty($search)) {
        // Adjust your search fields
        $dataQuery .= " AND (descripcion LIKE ? OR serial LIKE ? OR custodio LIKE ?)"; 
        $params[] = '%' . $search . '%';
        $params[] = '%' . $search . '%';
        $params[] = '%' . $search . '%';
        $types .= 'sss';
    }
    $dataQuery .= " LIMIT ? OFFSET ?"; // Add LIMIT and OFFSET placeholders
    $params[] = $limit;
    $params[] = $offset;
    $types .= 'ii'; // 'i' for integer, for limit and offset

    $stmtData = mysqli_prepare($conexion, $dataQuery);
    if ($stmtData === false) {
        throw new Exception("Error al preparar la consulta de datos: " . mysqli_error($conexion));
    }

    // Bind parameters for the data query
    mysqli_stmt_bind_param($stmtData, $types, ...$params);
    
    mysqli_stmt_execute($stmtData);
    $result = mysqli_stmt_get_result($stmtData);
    
    $properties = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $properties[] = $row;
    }
    mysqli_free_result($result);
    mysqli_stmt_close($stmtData);

    // Define your headers dynamically or statically
    $headers = [
        'ID', 'Cód. Act. Fijo', 'descripcion', 'Marca', 'Modelo', 'Serial', 'Estatus',
        'Cód. Unidad', 'Custodio', 'Cédula Custodio', 'Cargo Custodio', 'Gerencia Custodio',
        'Asignación', 'Observación', 'ADQ', 'Doc', 'Fecha', 'Monto', 'Fecha Mov.'
    ];

    echo json_encode([
        'success' => true,
        'properties' => $properties,
        'headers' => $headers,
        'totalProperties' => $totalProperties // IMPORTANT: You must return the total number of properties
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
} finally {
    // Close the conexionection
    if ($conexion) {
        mysqli_close($conexion);
    }
}
?>