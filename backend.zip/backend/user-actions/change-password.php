<?php
// backend/user-actions/change-password.php

session_start(); // Always start the session at the very beginning

require '../../backend/connect/connect.php'; // Adjust this path if necessary for your server setup

header('Content-Type: application/json');

if (!$conexion) {
    echo json_encode(['success' => false, 'message' => 'Error: No se pudo conectar a la base de datos.']);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // --- Crucial Security Check: Ensure the user ID is available from the session
    // and that the reset token is also present and valid (though not strictly necessary for ID).
    // The reset token is a good practice to prevent direct jumps to this page.
    if (!isset($_SESSION['restablecer_user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Acceso no autorizado. ID de usuario para restablecer no encontrado en la sesión.']);
        exit();
    }
    // Optional: Check if the token is also set, for an extra layer of security
    // if (!isset($_SESSION['restablecer_token'])) {
    //     echo json_encode(['success' => false, 'message' => 'Acceso no autorizado. Token de restablecimiento no encontrado.']);
    //     exit();
    // }

    // Get the user ID from the session variable set by verificar_respuestas_seguridad.php
    $user_id = $_SESSION['restablecer_user_id'];

    // Receive password data from the JavaScript frontend
    $contrasena = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm-password'] ?? ''; // This was the typo fix!

    $validationErrors = []; // Array to collect specific password errors

    // --- Backend Password Validation ---

    // 1. Passwords cannot be empty
    if (empty($contrasena)) {
        $validationErrors['password_empty'] = "La contraseña no puede estar vacía.";
    }
    if (empty($confirm_password)) {
        $validationErrors['confirm_password_empty'] = "La confirmación de contraseña no puede estar vacía.";
    }

    // 2. Passwords must match (only if not empty to avoid redundant messages)
    if (!empty($contrasena) && !empty($confirm_password) && $contrasena !== $confirm_password) {
        $validationErrors['password_match'] = "Las contraseñas no coinciden.";
    }

    // 3. Password strength rules (only if the password field itself is not empty)
    if (empty($validationErrors['password_empty'])) {
        if (strlen($contrasena) < 8) {
            $validationErrors['password_strength'][] = 'Debe tener al menos 8 caracteres.';
        }
        if (!preg_match('/[0-9]/', $contrasena)) {
            $validationErrors['password_strength'][] = 'Debe contener al menos un número.';
        }
        if (!preg_match('/[a-z]/', $contrasena)) {
            $validationErrors['password_strength'][] = 'Debe contener al menos una letra minúscula.';
        }
        if (!preg_match('/[^A-Za-z0-9]/', $contrasena)) {
            $validationErrors['password_strength'][] = 'Debe contener al menos un carácter especial.';
        }
        if (!preg_match('/[A-Z]/', $contrasena)) {
            $validationErrors['password_strength'][] = 'Debe contener al menos una letra mayúscula.';
        }
    }

    // --- If there are validation errors, send the response and exit ---
    if (!empty($validationErrors)) {
        echo json_encode([
            'success' => false,
            'message' => 'Errores en la validación de la contraseña.',
            'errors' => $validationErrors
        ]);
        exit();
    }

    // If password validation passes, hash the password and update the database
    $contrasena_hash = password_hash($contrasena, PASSWORD_BCRYPT);

    try {
        // Prepare the UPDATE statement to change the password for the specific user ID
        $query_update_password = "UPDATE usuarios SET contrasena = ? WHERE id = ?";
        $stmt_update_password = $conexion->prepare($query_update_password);

        if (!$stmt_update_password) {
            throw new Exception("Error al preparar la consulta de actualización: " . $conexion->error);
        }

        // Bind parameters: 's' for string (hashed password), 'i' for integer (user ID)
        $stmt_update_password->bind_param("si", $contrasena_hash, $user_id);

        if (!$stmt_update_password->execute()) {
            throw new Exception("Error al ejecutar la actualización de contraseña: " . $stmt_update_password->error);
        }

        if ($stmt_update_password->affected_rows === 0) {
            // This means no rows were updated. Could be user_id not found or password is already the same.
            echo json_encode(['success' => false, 'message' => 'No se pudo actualizar la contraseña. El usuario no existe o la contraseña es la misma.']);
        } else {
            // Password updated successfully
            echo json_encode(['success' => true, 'message' => "Contraseña actualizada exitosamente."]);

            // --- Security Best Practice: Invalidate the session after password change ---
            // This forces the user to log in again with the new password.
            session_unset();    // Unset all session variables
            session_destroy();  // Destroy the session

            // IMPORTANT: If you want to redirect after success and don't rely on the current session for login,
            // the JavaScript will handle the redirect.
        }

        $stmt_update_password->close();

    } catch (Exception $e) {
        error_log("Error al cambiar la contraseña en la base de datos: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error interno del servidor al actualizar la contraseña: ' . $e->getMessage()]);
    }

} else {
    // If the request method is not POST
    echo json_encode(['success' => false, 'message' => 'Método de solicitud no válido. Solo se aceptan solicitudes POST.']);
}

// Close the database connection
$conexion->close();
?>