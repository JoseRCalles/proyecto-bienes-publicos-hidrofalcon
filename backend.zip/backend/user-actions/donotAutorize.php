<?php
// ¡MUY IMPORTANTE! session_start() debe ser la primera cosa en el script
// después de <?php, sin ningún espacio o línea en blanco antes.
session_start();

// Verifica si la variable de sesión que indica que el usuario está logueado existe
// y tiene un valor (ej. el ID del usuario).
// Asumo que $_SESSION['usuario_id'] se establece al iniciar sesión.
if (!isset($_SESSION['usuario_id']) || empty($_SESSION['usuario_id'])) {
    // Si el usuario no está autenticado, redirige a la página de login.
    // Asegúrate de que esta ruta absoluta sea CORRECTA para tu página de login.
    // Basado en tu estructura y aclaración: /sistemahidrofalcon/frontend/index.php
    header('Location: /systemahidrofalcon/frontend/index.php?acceso_denegado=true'); // Opcional: añade un parámetro para mensaje
    exit(); // ¡Importante! Termina la ejecución del script aquí
}

// Si el script llega hasta aquí, el usuario está autenticado y la página puede mostrar su contenido normal.

// ... el resto de tu código PHP y HTML para la página ...

?>