<?php
header('Content-Type: application/json');

require_once '../../connect/connect.php'; // Asegúrate de que esta ruta sea correcta

$searchTerm = $_GET['search'] ?? '';
$gerenciaId = $_GET['gerencia'] ?? '';
$page = (int) ($_GET['page'] ?? 1); // Página actual, por defecto 1
$limit = (int) ($_GET['limit'] ?? 5); // Límite de resultados por página, por defecto 5

// Calcular el OFFSET
$offset = ($page - 1) * $limit;

// --- 1. Consulta para obtener el total de resultados (sin LIMIT ni OFFSET) ---
$countSql = "SELECT
                COUNT(t.id) AS total_count
             FROM
                trabajador t
             LEFT JOIN
                cargo c ON t.cargo = c.id
             LEFT JOIN
                gerencia_adm ga ON t.gerencia = ga.id
             WHERE 1=1";

$countParams = [];
$countTypes = '';

if (!empty($searchTerm)) {
    $countSql .= " AND (t.cedula LIKE ? OR t.nombres LIKE ? OR t.apellidos LIKE ?)";
    $countParams[] = '%' . $searchTerm . '%';
    $countParams[] = '%' . $searchTerm . '%';
    $countParams[] = '%' . $searchTerm . '%';
    $countTypes .= 'sss';
}

if (!empty($gerenciaId)) {
    $countSql .= " AND t.gerencia = ?";
    $countParams[] = $gerenciaId;
    $countTypes .= 'i';
}

// --- 2. Consulta para obtener los resultados de la página actual (con LIMIT y OFFSET) ---
$dataSql = "SELECT
                t.id,
                t.cedula,
                t.nombres,
                t.apellidos,
                t.telefono,
                c.cargo AS nombre_cargo,
                ga.gerencia AS nombre_gerencia
            FROM
                trabajador t
            LEFT JOIN
                cargo c ON t.cargo = c.id
            LEFT JOIN
                gerencia_adm ga ON t.gerencia = ga.id
            WHERE 1=1";

$dataParams = [];
$dataTypes = '';

if (!empty($searchTerm)) {
    $dataSql .= " AND (t.cedula LIKE ? OR t.nombres LIKE ? OR t.apellidos LIKE ?)";
    $dataParams[] = '%' . $searchTerm . '%';
    $dataParams[] = '%' . $searchTerm . '%';
    $dataParams[] = '%' . $searchTerm . '%';
    $dataTypes .= 'sss';
}

if (!empty($gerenciaId)) {
    $dataSql .= " AND t.gerencia = ?";
    $dataParams[] = $gerenciaId;
    $dataTypes .= 'i';
}

$dataSql .= " ORDER BY t.nombres ASC, t.apellidos ASC";
$dataSql .= " LIMIT ? OFFSET ?"; // Añadir LIMIT y OFFSET
$dataParams[] = $limit;
$dataParams[] = $offset;
$dataTypes .= 'ii'; // 'i' para limit y offset

try {
    // --- Ejecutar la consulta de conteo ---
    $stmtCount = $conexion->prepare($countSql);
    if ($stmtCount === false) {
        throw new Exception("Error en la preparación de la consulta de conteo: " . $conexion->error);
    }
    if (!empty($countParams)) {
        call_user_func_array([$stmtCount, 'bind_param'], refValues(array_merge([$countTypes], $countParams)));
    }
    $stmtCount->execute();
    $resultCount = $stmtCount->get_result();
    $totalCount = $resultCount->fetch_assoc()['total_count'] ?? 0;
    $stmtCount->close();

    // --- Ejecutar la consulta de datos paginados ---
    $stmtData = $conexion->prepare($dataSql);
    if ($stmtData === false) {
        throw new Exception("Error en la preparación de la consulta de datos: " . $conexion->error);
    }
    if (!empty($dataParams)) {
        call_user_func_array([$stmtData, 'bind_param'], refValues(array_merge([$dataTypes], $dataParams)));
    }
    $stmtData->execute();
    $resultData = $stmtData->get_result();

    $employees = [];
    if ($resultData) {
        while ($row = $resultData->fetch_assoc()) {
            $employees[] = $row;
        }
    }
    $stmtData->close();

    // Devolver los datos y el total de resultados
    echo json_encode(['employees' => $employees, 'total_employees' => $totalCount]);
} catch (Exception $e) {
    error_log("Error searching employees (with pagination): " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'No se pudo realizar la búsqueda de trabajadores con paginación.']);
}

// Función auxiliar para pasar valores por referencia a bind_param
function refValues($arr){
    if (strnatcmp(phpversion(),'5.3') >= 0) // PHP 5.3+
    {
        $refs = array();
        foreach($arr as $key => $value)
            $refs[$key] = &$arr[$key];
        return $refs;
    }
    return $arr;
}

?>