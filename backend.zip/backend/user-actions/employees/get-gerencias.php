<?php
header('Content-Type: application/json');

// La ruta a tu archivo de conexión. Asegúrate que $conexion sea un objeto MySQLi
// Si 'connect.php' devuelve un objeto PDO, entonces el problema está en cómo se crea la conexión allí.
// Pero por el error, parece que devuelve un objeto MySQLi.
require_once '../../connect/connect.php'; 

try {
    // Asegúrate de que $conexion sea tu objeto MySQLi de conexión a la base de datos
    // y que la variable de conexión se llame $conexion
    $query = "SELECT id, gerencia AS nombre FROM gerencia_adm ORDER BY gerencia ASC";
    
    // Preparar la consulta con MySQLi
    $stmt = $conexion->prepare($query); 
    
    // Verificar si la preparación fue exitosa
    if ($stmt === false) {
        throw new Exception("Error en la preparación de la consulta: " . $conexion->error);
    }

    // Ejecutar la consulta
    $stmt->execute();
    
    // Obtener los resultados usando get_result() para MySQLi
    $result = $stmt->get_result();

    $gerencias = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) { // fetch_assoc() para obtener filas asociativas
            $gerencias[] = $row;
        }
    }
    
    // Cerrar la sentencia
    $stmt->close();
    
    echo json_encode($gerencias);

} catch (Exception $e) { // Cambiado a Exception general para capturar errores de preparación y conexión
    error_log("Error fetching gerencias: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'No se pudo recuperar la lista de gerencias. Por favor, inténtelo más tarde.']);
}
?>