<?php
// backend/validations/logout.php

session_start();

$_SESSION = array();

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

session_destroy();

// **** RUTA ABSOLUTA CORREGIDA PARA EL LOGIN ****
// Asumiendo que tu página de login es frontend/index.php
header('Location: /systemahidrofalcon/frontend/pages/login.php?sesion_cerrada=true'); // <--- CAMBIADO A .php
exit();
?>