<?php
header('Content-Type: application/json');

require_once '../../connect/connect.php'; // Ensure this path is correct for your DB connection.

$response = ['success' => false, 'message' => ''];

// Verify if the $conexion variable is defined after inclusion
if (!isset($conexion) || $conexion->connect_error) {
    $response['message'] = 'Error: Could not establish a database connection.';
    echo json_encode($response);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $errors = [];

    // Data collection and validation
    $cod_act_f = trim($_POST['cod_act_f'] ?? '');
    if (empty($cod_act_f)) {
        $errors['cod_act_f'] = 'The Fixed Asset Code is mandatory.';
    } elseif (!is_numeric($cod_act_f)) {
        $errors['cod_act_f'] = 'The Fixed Asset Code must be a number.';
    }

    $descripcion = trim($_POST['descripcion'] ?? '');
    if (empty($descripcion)) {
        $errors['descripcion'] = 'Description is mandatory.'; // CORRECTED MESSAGE
    }

    $color = trim($_POST['color'] ?? '');
    if (empty($color)) {
        $errors['color'] = 'Color is mandatory.';
    }

    $marca = trim($_POST['marca'] ?? '');
    if (empty($marca)) {
        $errors['marca'] = 'Brand is mandatory.';
    }

    $modelo = trim($_POST['modelo'] ?? '');
    if (empty($modelo)) {
        $errors['modelo'] = 'Model is mandatory.';
    }

    $serial = trim($_POST['serial'] ?? '');
    if (empty($serial)) {
        $errors['serial'] = 'Serial is mandatory.';
    }

    $estatus = trim($_POST['estatus'] ?? '');
    if (empty($estatus)) {
        $errors['estatus'] = 'Status is mandatory.';
    } elseif (!is_numeric($estatus)) {
        $errors['estatus'] = 'Status must be a number.';
    }

    $codigo_u_u = trim($_POST['codigo_u_u'] ?? '');
    if (empty($codigo_u_u)) {
        $errors['codigo_u_u'] = 'Unit Code is mandatory.';
    }

    // --- IMPORTANT CHANGE HERE FOR CUSTODIAN (nullable) ---
    $custodio_id = trim($_POST['trabajador_id'] ?? ''); // This will be empty if not selected

    // If it's NOT empty, then validate it as a number.
    // If it IS empty, we'll treat it as NULL for the database.
    if (!empty($custodio_id) && !is_numeric($custodio_id)) {
        $errors['trabajador_id'] = 'The assigned worker ID is not valid.';
    }
    // No error if it's empty, as it's now nullable.
    // We'll convert it to actual NULL later if empty.

    $asignacion = trim($_POST['asignacion'] ?? '');
    if (empty($asignacion)) {
        $errors['asignacion'] = 'Assignment is mandatory.';
    }

    $observacion = trim($_POST['observacion'] ?? '');
    if (empty($observacion)) {
        $errors['observacion'] = 'Observation is mandatory.';
    }

    $adq = trim($_POST['adq'] ?? '');
    if (empty($adq)) {
        $errors['adq'] = 'Acquisition is mandatory.';
    }

    $doc = trim($_POST['doc'] ?? '');
    if (empty($doc)) {
        $errors['doc'] = 'Document is mandatory.';
    }

    $fecha = trim($_POST['fecha'] ?? '');
    if (empty($fecha)) {
        $errors['fecha'] = 'Date is mandatory.';
    }

    $monto = trim($_POST['monto'] ?? '');
    if (empty($monto)) {
        $errors['monto'] = 'Amount is mandatory.';
    } elseif (!is_numeric($monto) || $monto < 0) {
        $errors['monto'] = 'Amount must be a positive number.';
    }

    $fecha_mov = trim($_POST['fecha_mov'] ?? '');
    if (empty($fecha_mov)) {
        $errors['fecha_mov'] = 'Movement date is mandatory.';
    }

    if (!empty($errors)) {
        $response['message'] = 'Validation errors.';
        $response['errors'] = $errors;
        echo json_encode($response);
        exit;
    }

    try {
        // Prepare the SQL INSERT statement.
        // The column list includes 'custodio'.
        // CORRECTED: Added one more '?' to match the 16 columns
        $sql = "INSERT INTO activo (cod_act_f, descripcion, color, marca, modelo, serial, estatus, codigo_u_u, custodio, asignacion, observacion, adq, doc, fecha, monto, fecha_mov)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"; // Now 16 placeholders

        $stmt = $conexion->prepare($sql);

        if ($stmt === false) {
            throw new Exception("Error preparing query: " . $conexion->error);
        }

        // --- Handle nullable custodio_id for bind_param ---
        // If $custodio_id is empty, set it to NULL explicitly for PHP's bind_param.
        // MySQLi will then interpret this as SQL NULL if the column is nullable.
        $custodio_id_for_db = !empty($custodio_id) ? (int)$custodio_id : null;

        // Define types for bind_param. 'i' for integer, 's' for string, 'd' for double.
        // The type sequence must match the column order in SQL and the variable order.
        // CORRECTED: 'vars: $$color,' changed to '$color,'
        $stmt->bind_param("issssssisssssdss",
            $cod_act_f,
            $descripcion,
            $color, // CORRECTED SYNTAX
            $marca,
            $modelo,
            $serial,
            $estatus,
            $codigo_u_u,
            $custodio_id_for_db, // <--- Pass the potentially NULL or integer value here
            $asignacion,
            $observacion,
            $adq,
            $doc,
            $fecha,
            $monto,
            $fecha_mov
        );

        // Execute the statement
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Asset registered successfully.';
        } else {
            throw new Exception("Error executing query: " . $stmt->error);
        }

        // Close the statement
        $stmt->close();

    } catch (Exception $e) {
        $response['message'] = 'Error: ' . $e->getMessage();
    } finally {
        // Close the database connection if it's open
        if (isset($conexion) && $conexion instanceof mysqli) {
            $conexion->close();
        }
    }

} else {
    $response['message'] = 'Request method not allowed.';
}

echo json_encode($response);
?>