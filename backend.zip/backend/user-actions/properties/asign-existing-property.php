<?php
header('Content-Type: application/json'); // Ensure JSON response
// Add CORS headers if your frontend is on a different domain/port
// header('Access-Control-Allow-Origin: *');
// header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
// header('Access-Control-Allow-Headers: Content-Type');

// Assuming conexionect.php establishes a mysqli conexionection and makes it available as $conexion
// Make sure '../../conexionect/conexionect.php' actually creates a variable named $conexion
require '../../connect/connect.php'; 

$response = ['success' => false, 'message' => ''];

// --- FIX 1: Corrected conexionection variable name and comprehensive error check ---
// Check if the conexionection variable is set AND if there's a conexionection error
if (!isset($conexion)) {
    $response['message'] = 'Error de conexión a la base de datos: ';
    echo json_encode($response);
    exit; // Exit immediately if conexionection fails
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get data from the POST request
    $asset_id = filter_input(INPUT_POST, 'asset_id', FILTER_VALIDATE_INT);
    $new_custodio_id = filter_input(INPUT_POST, 'new_custodio_id', FILTER_VALIDATE_INT);
    
    // For string inputs, direct access from $_POST is fine,
    // and prepared statements handle SQL injection.
    // Use null coalescing operator (??) for robustness against missing POST keys.
    $asignacion = $_POST['asignacion'] ?? ''; 
    $codigo_u_u = $_POST['codigo_u_u'] ?? '';

    // Basic validation on the server side
    // --- FIX 2: More robust validation for integers ---
    if ($asset_id === false || $asset_id === null || $new_custodio_id === false || $new_custodio_id === null) {
        $response['message'] = 'ID de activo o custodio no válidos (deben ser números enteros).';
        echo json_encode($response);
        // --- FIX 3: Guard close() call ---
        // Only close if $conexion is a valid mysqli object and was successfully conexionected
        if (isset($conexion)) {
            $conexion->close();
        }
        exit;
    }

    // --- FIX 4: Corrected SQL query to include all intended fields ---
    $query = "UPDATE activo 
              SET 
                  custodio = ?, 
                  asignacion = ?, 
                  codigo_u_u = ? 
              WHERE 
                  id = ?";

    // Prepare the statement
    // --- FIX 5: Corrected bind_param format string and arguments ---
    // 'i' for integer, 's' for string.
    // Order: new_custodio_id (int), asignacion (string), codigo_u_u (string), asset_id (int)
    if ($stmt = $conexion->prepare($query)) {
        $stmt->bind_param("issi", $new_custodio_id, $asignacion, $codigo_u_u, $asset_id);

        // Execute the statement
        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                $response['success'] = true;
                $response['message'] = 'Activo asignado y custodio actualizado exitosamente.';
            } else {
                // If affected_rows is 0, it means the ID was valid but no row was updated
                // (e.g., asset_id didn't exist or values were already the same)
                $response['message'] = 'No se encontró el activo o no se realizaron cambios.';
            }
        } else {
            $response['message'] = 'Error al ejecutar la actualización: ' . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        $response['message'] = 'Error al preparar la consulta: ' . $conexion->error;
    }
} else {
    $response['message'] = 'Método de solicitud no permitido.';
}

echo json_encode($response);

// --- FIX 6: Ensure conexionection is closed only if it's a valid object ---
if (isset($conexion)) {
    $conexion->close();
}
?>