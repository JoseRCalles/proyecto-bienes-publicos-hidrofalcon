<?php
// get-filtered-properties.php

header('Content-Type: application/json'); // Ensure this is at the very top

require '../../connect/connect.php'; // Assuming this file establishes $conexion as a mysqli object

$response = ['success' => false, 'message' => ''];
$assets = [];
$total_assets = 0;

// Check connection *after* including connect.php
if ($conexion->connect_error) {
    $response['message'] = "Connection failed: " . $conexion->connect_error;
    error_log("Database Connection Error: " . $conexion->connect_error);
    echo json_encode($response);
    exit();
}

try {
    $search = $_GET['search'] ?? '';
    $estatus = $_GET['estatus'] ?? ''; // This will be the estatus ID
    $page = (int)($_GET['page'] ?? 1);
    $limit = (int)($_GET['limit'] ?? 10);
    $offset = ($page - 1) * $limit;

    $where_clauses = [];
    $params = [];
    $param_types = ''; // String to hold parameter types for bind_param

    // ADDITION: Filter for assets that do NOT have a custodian assigned
    // Assuming 'custodio_id' is the column that holds the custodian's ID in the 'activo' table.
    // If an asset has no custodian, this column should be NULL.
    $where_clauses[] = "p.custodio IS NULL";


    if (!empty($search)) {
        $where_clauses[] = "(p.cod_act_f LIKE ? OR p.serial LIKE ? OR p.marca LIKE ? OR p.modelo LIKE ?)";
        $params[] = '%' . $search . '%';
        $params[] = '%' . $search . '%';
        $params[] = '%' . $search . '%';
        $params[] = '%' . $search . '%';
        $param_types .= 'ssss'; // s for string
    }

    // Assuming the foreign key in 'activo' is named 'estatus' and links to 'estatus.id'
    if (!empty($estatus)) {
        $where_clauses[] = "p.estatus = ?"; // Use 'p.estatus' for the foreign key in the 'activo' table
        $params[] = $estatus;
        $param_types .= 'i'; // i for integer
    }

    $where_sql = count($where_clauses) > 0 ? " WHERE " . implode(" AND ", $where_clauses) : "";

    // --- Count total assets (for pagination) ---
    // Changed table name from 'properties' to 'activo'
    $count_sql = "SELECT COUNT(*) AS total FROM activo p" . $where_sql;
    $stmt_count = $conexion->prepare($count_sql);

    if ($stmt_count === false) {
        throw new Exception("Failed to prepare count statement: " . $conexion->error);
    }

    // Only bind parameters for the WHERE clause for the count query
    if (!empty($params)) {
        // Create a temporary array for binding that only includes parameters for the WHERE clause
        $count_bind_params = array_merge([$param_types], $params);
        call_user_func_array([$stmt_count, 'bind_param'], refValues($count_bind_params));
    }

    $stmt_count->execute();
    $result_count = $stmt_count->get_result();
    $total_assets = $result_count->fetch_assoc()['total'];
    $stmt_count->close();

    // --- Fetch assets with JOIN to get status name ---
    // Corrected the SELECT for estatus_name and JOIN condition
    $sql = "SELECT
                p.id,
                p.cod_act_f,
                p.serial,
                p.marca,
                p.modelo,
                s.estatus AS estatus_name -- This gets the name from the 'estatus' table
            FROM
                activo p
            LEFT JOIN
                estatus s ON p.estatus = s.id -- Changed p.estatus_id to p.estatus
            {$where_sql}
            LIMIT ? OFFSET ?";

    $stmt = $conexion->prepare($sql);

    if ($stmt === false) {
        throw new Exception("Failed to prepare main statement: " . $conexion->error);
    }

    // Add limit and offset parameters
    $params_for_main_query = $params; // Start with the existing WHERE clause parameters
    $params_for_main_query[] = $limit;
    $params_for_main_query[] = $offset;
    $param_types_for_main_query = $param_types . 'ii'; // Add 'ii' for limit and offset

    // Bind all parameters for the main query
    $bind_params_main = array_merge([$param_types_for_main_query], $params_for_main_query);
    call_user_func_array([$stmt, 'bind_param'], refValues($bind_params_main));

    $stmt->execute();
    $result = $stmt->get_result();
    $assets = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $response['success'] = true;
    $response['assets'] = $assets;
    $response['total_assets'] = $total_assets;

} catch (Exception $e) {
    $response['message'] = "Error: " . $e->getMessage();
    error_log("Asset Fetch Error (MySQLi): " . $e->getMessage()); // Log the error for debugging
} finally {
    // Close MySQLi connection
    if ($conexion) {
        $conexion->close();
    }
}

echo json_encode($response);

/**
 * Helper function for mysqli_stmt_bind_param to pass parameters by reference.
 * Needed when using call_user_func_array with bind_param.
 */
function refValues($arr) {
    if (strnatcmp(PHP_VERSION, '5.3') >= 0) // PHP 5.3+
    {
        $refs = array();
        foreach($arr as $key => $value)
            $refs[$key] = &$arr[$key];
        return $refs;
    }
    return $arr;
}
?>
