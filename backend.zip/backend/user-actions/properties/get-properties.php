<?php
// C:\wamp64\www\systemaHidrofalcon\backend\get-properties-data.php

header('Content-Type: application/json'); // Indicamos que la respuesta es JSON

// Activar la visualización de errores solo para desarrollo
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Ajusta esta ruta a tu archivo de conexión.
require '../../connect/connect.php';

$response = [
    'success' => false,
    'message' => '',
    'headers' => [],
    'data' => [],
    'total_count' => 0 // Para la métrica total
];

// Verificar conexión a la base de datos
if (!isset($conexion) || $conexion->connect_error) {
    $response['message'] = 'Error de conexión a la base de datos: ' . ($conexion->connect_error ?? 'Desconocido');
    echo json_encode($response);
    exit;
}

try {
    // Obtener término de búsqueda si existe
    $search_term = $_GET['search'] ?? '';
    $search_term = '%' . $conexion->real_escape_string($search_term) . '%'; // Para búsqueda LIKE

    // Consulta SQL con LEFT JOIN para obtener toda la información relevante
    // Usamos ALIASES para las columnas y evitar conflictos de nombres
    $sql = "
        SELECT
            a.id,
            a.cod_act_f,
            a.color,
            a.marca,
            a.modelo,
            a.serial,
            a.estatus, -- Esto sigue siendo el ID, si quieres el nombre, tendrías que hacer otro JOIN a tabla 'estatus'
            a.codigo_u_u,
            CONCAT(t.nombres, ' ', t.apellidos) AS custodio_completo,
            t.cedula AS custodio_cedula,
            c.cargo AS nombre_cargo,
            g.gerencia AS nombre_gerencia,
            a.asignacion,
            a.observacion,
            a.adq,
            a.doc,
            a.fecha,
            a.monto,
            a.fecha_mov
        FROM
            activo AS a
        LEFT JOIN
            trabajador AS t ON a.custodio = t.id
        LEFT JOIN
            cargo AS c ON t.id = c.id
        LEFT JOIN
            gerencia_adm AS g ON t.id = g.id
        WHERE
            a.cod_act_f LIKE ? OR
            a.color LIKE ? OR
            a.marca LIKE ? OR
            a.modelo LIKE ? OR
            a.serial LIKE ? OR
            CONCAT(t.nombres, ' ', t.apellidos) LIKE ? OR
            t.cedula LIKE ? OR
            c.cargo LIKE ? OR
            g.gerencia LIKE ? OR
            a.asignacion LIKE ? OR
            a.observacion LIKE ? OR
            a.adq LIKE ? OR
            a.doc LIKE ? OR
            a.fecha LIKE ? OR
            a.fecha_mov LIKE ?
        ORDER BY a.id ASC; -- Ordena por ID, puedes cambiar el criterio
    ";

    $stmt = $conexion->prepare($sql);
    if ($stmt === false) {
        throw new Exception("Error al preparar la consulta: " . $conexion->error);
    }

    // Bind de parámetros para la búsqueda (tantos 's' como ? en el WHERE)
    $stmt->bind_param(
        "sssssssssssssss", // 15 's' para 15 LIKE's
        $search_term, $search_term, $search_term, $search_term, $search_term,
        $search_term, $search_term, $search_term, $search_term, $search_term,
        $search_term, $search_term, $search_term, $search_term, $search_term
    );

    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        $data = [];
        $headers_map = [
            'id' => 'ID',
            'cod_act_f' => 'Cod. Act. Fijo',
            'color' => 'Color',
            'marca' => 'Marca',
            'modelo' => 'Modelo',
            'serial' => 'Serial',
            'estatus' => 'Estatus ID', // Si necesitas el nombre del estatus, otro JOIN
            'codigo_u_u' => 'Cod. Unidad',
            'custodio_completo' => 'Custodio',
            'custodio_cedula' => 'Cédula Custodio',
            'nombre_cargo' => 'Cargo', // Nueva columna
            'nombre_gerencia' => 'Gerencia', // Nueva columna
            'asignacion' => 'Asignación',
            'observacion' => 'Observación',
            'adq' => 'Adquisición',
            'doc' => 'Documento',
            'fecha' => 'Fecha Adq.',
            'monto' => 'Monto',
            'fecha_mov' => 'Fecha Mov.'
        ];

        // Obtener nombres de columnas reales de la consulta para el orden
        $fetched_headers = [];
        foreach ($result->fetch_fields() as $field) {
            // Usar el alias o el nombre original si no hay alias en el mapa
            $fetched_headers[$field->name] = $headers_map[$field->name] ?? ucfirst(str_replace('_', ' ', $field->name));
        }
        $response['headers'] = array_values($fetched_headers); // Solo los valores para el array de headers

        while ($row = $result->fetch_assoc()) {
            // Asegurarse de que los datos estén en el mismo orden que los headers y HTML-escapados
            $formatted_row = [];
            foreach ($fetched_headers as $key => $display_name) {
                // htmlspecialchars para evitar XSS al mostrar en el HTML
                $formatted_row[] = htmlspecialchars($row[$key] ?? '');
            }
            $data[] = $formatted_row;
        }

        $response['success'] = true;
        $response['data'] = $data;
        $response['total_count'] = count($data); // El conteo total de resultados filtrados
        $result->free();
    } else {
        throw new Exception("Error al obtener datos de activos: " . $conexion->error);
    }

    $stmt->close();

} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    error_log("Error en get-properties-data.php: " . $e->getMessage()); // Registrar en el log del servidor
} finally {
    if (isset($conexion) && $conexion instanceof mysqli) {
        $conexion->close();
    }
}

echo json_encode($response);
?>