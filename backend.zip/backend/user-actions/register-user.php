<?php
// backend/user-actions/register-user.php

// Iniciar la sesión si aún no está iniciada (puede que no sea necesario para el registro, pero no hace daño)
session_start();

// Incluir archivo de conexión a la base de datos
require '../connect/connect.php';

// Establecer el tipo de contenido para la respuesta JSON
header('Content-Type: application/json');

// Verificar si la conexión a la base de datos fue exitosa
if (!$conexion) {
    $response = ['success' => false, 'message' => 'Error: No se pudo conectar a la base de datos. Por favor, revisa el archivo de conexión.'];
    echo json_encode($response);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibir y limpiar los datos del formulario
    $nombre = strtolower(trim($_POST['nombres'] ?? ''));
    $apellido = strtolower(trim($_POST['apellidos'] ?? ''));
    $usuario = strtolower(trim($_POST['usuario'] ?? ''));
    $cedula = trim($_POST['cedula'] ?? '');
    $cargo = strtolower(trim($_POST['cargo'] ?? ''));
    $gerencia = strtolower(trim($_POST['gerencia'] ?? ''));
    $pregunta1 = $_POST['p1'] ?? '';
    $respuesta1 = trim($_POST['r1'] ?? '');
    $pregunta2 = $_POST['p2'] ?? '';
    $respuesta2 = trim($_POST['r2'] ?? '');

    // Contraseñas sin trim para preservar espacios iniciales/finales si son intencionales (aunque no recomendado)
    $contrasena = $_POST['contrasena'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Array para recolectar errores de validación de contraseña
    $validationErrors = [];

    // --- Validaciones de Contraseña ---
    if (empty($contrasena)) {
        $validationErrors['password_empty'] = "La contraseña no puede estar vacía.";
    }
    if (empty($confirm_password)) {
        $validationErrors['confirm_password_empty'] = "La confirmación de contraseña no puede estar vacía.";
    }

    if (!empty($contrasena) && !empty($confirm_password) && $contrasena !== $confirm_password) {
        $validationErrors['password_match'] = "Las contraseñas no coinciden.";
    }

    // Reglas de fortaleza de contraseña (solo si la contraseña no está vacía)
    if (empty($validationErrors['password_empty'])) {
        if (strlen($contrasena) < 8) { // Preferible 8 caracteres o más para seguridad
            $validationErrors['password_strength'][] = 'Debe tener al menos 8 caracteres.';
        }
        if (!preg_match('/[0-9]/', $contrasena)) {
            $validationErrors['password_strength'][] = 'Debe contener al menos un número.';
        }
        if (!preg_match('/[a-z]/', $contrasena)) {
            $validationErrors['password_strength'][] = 'Debe contener al menos una letra minúscula.';
        }
        if (!preg_match('/[^A-Za-z0-9]/', $contrasena)) {
            $validationErrors['password_strength'][] = 'Debe contener al menos un carácter especial.';
        }
        if (!preg_match('/[A-Z]/', $contrasena)) {
            $validationErrors['password_strength'][] = 'Debe contener al menos una letra mayúscula.';
        }
    }

    // --- Validación de Otros Campos ---
    if (strlen($nombre) > 30 || strlen($apellido) > 30 || strlen($usuario) > 30 || strlen($gerencia) > 30 || strlen($cargo) > 30) {
        $validationErrors['general'] = 'El nombre, apellido, usuario, gerencia y cargo no deben tener más de 30 caracteres.';
    }

    if (!ctype_digit($cedula) || $cedula < 0) {
        $validationErrors['cedula'] = 'La cédula debe ser un número positivo.';
    }
    if (strlen($cedula) > 11) {
        $validationErrors['cedula'] = 'La cédula no debe contener más de 11 dígitos.';
    }

    // Si hay errores de validación, enviar la respuesta y salir
    if (!empty($validationErrors)) {
        echo json_encode([
            'success' => false,
            'message' => 'Errores de validación.',
            'errors' => $validationErrors
        ]);
        exit();
    }

    // --- Hashear la contraseña y las respuestas de seguridad ---
    $contrasena_hash = password_hash($contrasena, PASSWORD_BCRYPT); // BCRYPT es una buena opción, PASSWORD_DEFAULT usará el algoritmo más fuerte disponible
    $respuesta1_hash = password_hash($respuesta1, PASSWORD_BCRYPT);
    $respuesta2_hash = password_hash($respuesta2, PASSWORD_BCRYPT);

    // --- Verificar si el usuario o la cédula ya existen ---
    $query_check_user = "SELECT id FROM usuarios WHERE usuario = ?";
    $stmt_check_user = $conexion->prepare($query_check_user);
    $stmt_check_user->bind_param("s", $usuario);
    $stmt_check_user->execute();
    $result_check_user = $stmt_check_user->get_result();
    if ($result_check_user->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'El nombre de usuario ya existe.']);
        $stmt_check_user->close();
        exit();
    }
    $stmt_check_user->close();

    $query_check_cedula = "SELECT id FROM usuarios WHERE cedula = ?";
    $stmt_check_cedula = $conexion->prepare($query_check_cedula);
    $stmt_check_cedula->bind_param("s", $cedula);
    $stmt_check_cedula->execute();
    $result_check_cedula = $stmt_check_cedula->get_result();
    if ($result_check_cedula->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'La cédula ya existe.']);
        $stmt_check_cedula->close();
        exit();
    }
    $stmt_check_cedula->close();

    // --- Iniciar Transacción de Base de Datos ---
    $conexion->begin_transaction();

    try {
        // --- Insertar el nuevo usuario ---
        $query_insert_user = "INSERT INTO usuarios (nombres, apellidos, cedula, gerencia, cargo, usuario, contrasena, rango) VALUES (?, ?, ?, ?, ?, ?, ?, 1)";
        $stmt_insert_user = $conexion->prepare($query_insert_user);
        $stmt_insert_user->bind_param("sssssss", $nombre, $apellido, $cedula, $gerencia, $cargo, $usuario, $contrasena_hash);

        if (!$stmt_insert_user->execute()) {
            throw new Exception("Error al insertar usuario: " . $stmt_insert_user->error);
        }
        $user_id = $stmt_insert_user->insert_id;
        $stmt_insert_user->close();

        // --- Insertar las respuestas de seguridad ---
        $query_insert_respuestas = "INSERT INTO resp_seguridad (id_usuario, id_pregunta, respuesta) VALUES (?, ?, ?)";
        $stmt_insert_respuestas = $conexion->prepare($query_insert_respuestas);

        $stmt_insert_respuestas->bind_param("iis", $user_id, $pregunta1, $respuesta1_hash);
        if (!$stmt_insert_respuestas->execute()) {
            throw new Exception("Error al insertar respuesta de seguridad 1: " . $stmt_insert_respuestas->error);
        }

        $stmt_insert_respuestas->bind_param("iis", $user_id, $pregunta2, $respuesta2_hash);
        if (!$stmt_insert_respuestas->execute()) {
            throw new Exception("Error al insertar respuesta de seguridad 2: " . $stmt_insert_respuestas->error);
        }
        $stmt_insert_respuestas->close();

        // Si todo fue exitoso, confirmar la transacción
        $conexion->commit();
        echo json_encode(['success' => true, 'message' => "Usuario registrado exitosamente."]);

    } catch (Exception $e) {
        // Si hay algún error, revertir la transacción
        $conexion->rollback();
        error_log("Error en el registro del usuario (transacción): " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error al registrar el usuario: ' . $e->getMessage()]);
    }

} else {
    // Si el método de solicitud no es POST
    echo json_encode(['success' => false, 'message' => 'Método de solicitud no válido.']);
}

// Cerrar la conexión a la base de datos
$conexion->close();
?>