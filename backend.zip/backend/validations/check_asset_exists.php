<?php
// check_asset_exists.php

header('Content-Type: application/json'); // Indicate the response is JSON

// Require the connection file. This will make the $conexion variable available.
require_once '../../backend/connect/connect.php';

// Obtener los datos JSON de la solicitud POST
$input = file_get_contents('php://input');
$data = json_decode($input, true);

$codActivoFijo = $data['cod_activo_fijo'] ?? null;
$serial = $data['serial'] ?? null;

$response = ['exists' => false, 'field' => null];

// --- Start using $conexion instead of $mysqli ---

if ($codActivoFijo) {
    // Prepare the query to check for the fixed asset code
    $stmt = $conexion->prepare("SELECT COUNT(*) FROM activo WHERE cod_act_f = ?");
    $stmt->bind_param("s", $codActivoFijo);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    if ($count > 0) {
        $response['exists'] = true;
        $response['field'] = 'cod_activo_fijo';
        echo json_encode($response);
        $conexion->close(); // Close the connection if we exit early
        exit(); // Exit if a match is found
    }
}

if ($serial) {
    // Prepare the query to check for the serial
    $stmt = $conexion->prepare("SELECT COUNT(*) FROM activo WHERE serial = ?");
    $stmt->bind_param("s", $serial);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    if ($count > 0) {
        $response['exists'] = true;
        $response['field'] = 'serial';
        echo json_encode($response);
        $conexion->close(); // Close the connection if we exit early
        exit(); // Exit if a match is found
    }
}

// If we reach here, neither field exists in the database
echo json_encode($response);

$conexion->close(); // Close the connection at the end of the script
?>