<?php
// backend/user-actions/verificar_respuestas_seguridad.php

// Iniciar la sesión si aún no está iniciada (esto es útil si necesitas el ID de usuario de la sesión)
session_start();

// Incluir archivo de conexión a la base de datos
// Asegúrate de que 'connect.php' devuelve una variable $conexion o $conn que es el objeto de conexión MySQLi
require '../../backend/connect/connect.php';

// Establecer el tipo de contenido a JSON para las respuestas de la API
header('Content-Type: application/json');

// Verificar que la solicitud sea de tipo POST para mayor seguridad
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Verificar si se recibieron todos los parámetros necesarios del frontend
    if (isset($_POST['id_usuario'], $_POST['respuesta1'], $_POST['respuesta2'], $_POST['id_pregunta1'], $_POST['id_pregunta2'])) {
        // Limpiar y obtener los datos enviados
        $idUsuario = $_POST['id_usuario'];
        // Las respuestas no se convierten a minúsculas porque password_verify es sensible a mayúsculas/minúsculas
        $respuesta1Enviada = trim($_POST['respuesta1']);
        $respuesta2Enviada = trim($_POST['respuesta2']);
        $idPregunta1 = $_POST['id_pregunta1'];
        $idPregunta2 = $_POST['id_pregunta2'];

        $errores = []; // Array para almacenar mensajes de error específicos
        $respuestasCorrectas = true; // Bandera para controlar el resultado general

        // --- Inicio de la verificación de la primera pregunta ---

        // Preparar la consulta SQL para obtener el hash de la respuesta de seguridad de la primera pregunta
        // Necesitamos el ID del usuario y el ID de la pregunta específica
        $sql1 = "SELECT respuesta FROM resp_seguridad WHERE id_usuario = ? AND id_pregunta = ?";
        $stmt1 = $conexion->prepare($sql1);

        if ($stmt1) {
            // Vincular los parámetros: 'ii' significa dos enteros (id_usuario, id_pregunta1)
            $stmt1->bind_param("ii", $idUsuario, $idPregunta1);
            if ($stmt1->execute()) {
                $resultado1 = $stmt1->get_result();
                if ($resultado1 && $resultado1->num_rows === 1) {
                    $fila1 = $resultado1->fetch_assoc();
                    $hashAlmacenado1 = $fila1['respuesta']; // Obtener el hash de la base de datos

                    // Usar password_verify para comparar la respuesta enviada con el hash almacenado
                    if (!password_verify($respuesta1Enviada, $hashAlmacenado1)) {
                        $errores['pregunta1'] = 'La respuesta a la primera pregunta es incorrecta.';
                        $respuestasCorrectas = false; // Marcar como incorrecto
                    }
                } else {
                    // La pregunta de seguridad para el usuario no fue encontrada
                    $errores['pregunta1'] = 'Pregunta de seguridad 1 no encontrada para este usuario.';
                    $respuestasCorrectas = false;
                }
            } else {
                // Error al ejecutar la consulta de la primera pregunta
                error_log("Error al ejecutar la consulta para verificar respuesta 1: " . $stmt1->error);
                $errores['general'] = 'Error interno del servidor al verificar la primera respuesta.';
                $respuestasCorrectas = false;
            }
            $stmt1->close(); // Cerrar la sentencia preparada
        } else {
            // Error al preparar la consulta de la primera pregunta
            error_log("Error al preparar la consulta para verificar respuesta 1: " . $conexion->error);
            $errores['general'] = 'Error interno del servidor al preparar la primera consulta.';
            $respuestasCorrectas = false;
        }

        // --- Inicio de la verificación de la segunda pregunta ---

        // Preparar la consulta SQL para obtener el hash de la respuesta de seguridad de la segunda pregunta
        $sql2 = "SELECT respuesta FROM resp_seguridad WHERE id_usuario = ? AND id_pregunta = ?";
        $stmt2 = $conexion->prepare($sql2);

        if ($stmt2) {
            // Vincular los parámetros: 'ii' para id_usuario y id_pregunta2
            $stmt2->bind_param("ii", $idUsuario, $idPregunta2);
            if ($stmt2->execute()) {
                $resultado2 = $stmt2->get_result();
                if ($resultado2 && $resultado2->num_rows === 1) {
                    $fila2 = $resultado2->fetch_assoc();
                    $hashAlmacenado2 = $fila2['respuesta']; // Obtener el hash de la base de datos

                    // Usar password_verify para comparar la respuesta enviada con el hash almacenado
                    if (!password_verify($respuesta2Enviada, $hashAlmacenado2)) {
                        $errores['pregunta2'] = 'La respuesta a la segunda pregunta es incorrecta.';
                        $respuestasCorrectas = false; // Marcar como incorrecto
                    }
                } else {
                    // La pregunta de seguridad para el usuario no fue encontrada
                    $errores['pregunta2'] = 'Pregunta de seguridad 2 no encontrada para este usuario.';
                    $respuestasCorrectas = false;
                }
            } else {
                // Error al ejecutar la consulta de la segunda pregunta
                error_log("Error al ejecutar la consulta para verificar respuesta 2: " . $stmt2->error);
                $errores['general'] = 'Error interno del servidor al verificar la segunda respuesta.';
                $respuestasCorrectas = false;
            }
            $stmt2->close(); // Cerrar la sentencia preparada
        } else {
            // Error al preparar la consulta de la segunda pregunta
            error_log("Error al preparar la consulta para verificar respuesta 2: " . $conexion->error);
            $errores['general'] = 'Error interno del servidor al preparar la segunda consulta.';
            $respuestasCorrectas = false;
        }

        // --- Envío de la respuesta JSON al cliente ---

        if ($respuestasCorrectas) {
            // Si ambas respuestas son correctas, puedes establecer una variable de sesión o token
            // para permitir el siguiente paso (ej. restablecer contraseña).
            // ¡Importante!: Genera un token seguro para evitar ataques de CSRF si es un paso crítico.
            $restablecer_token = bin2hex(random_bytes(32)); // Genera un token aleatorio
            $_SESSION['restablecer_token'] = $restablecer_token; // Almacénalo en la sesión
            $_SESSION['restablecer_user_id'] = $idUsuario; // Guarda el ID de usuario para el siguiente paso

            echo json_encode([
                'response' => true,
                'message' => 'Respuestas de seguridad verificadas correctamente.',
                'token_para_restablecer' => $restablecer_token // Opcional, para enviar al cliente
            ]);
        } else {
            // Si hay errores, enviar el mensaje de error y los detalles
            echo json_encode([
                'response' => false,
                'error' => 'Una o ambas respuestas de seguridad son incorrectas.',
                'detalles' => $errores
            ]);
        }

    } else {
        // Si no se recibieron todos los parámetros necesarios del frontend
        echo json_encode(['response' => false, 'error' => 'Faltan parámetros en la solicitud.']);
    }
} else {
    // Si el método de solicitud no es POST
    echo json_encode(['response' => false, 'error' => 'Método de solicitud no válido. Solo se aceptan solicitudes POST.']);
}

// Cerrar la conexión a la base de datos al finalizar
$conexion->close();
?>