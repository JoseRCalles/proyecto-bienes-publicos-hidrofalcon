<?php

header('Content-Type: application/json');

require '../connect/connect.php';

// Verificar si la conexión a la base de datos se estableció correctamente
if (!$conexion) {
    echo json_encode(['response' => false, 'error' => 'Error al conectar a la base de datos.'], JSON_PRETTY_PRINT);
    exit();
}

function verificarCedula(mysqli $conexion, string $cedula): array {
    $sql = "SELECT cedula FROM usuarios WHERE cedula = ?";
    $stmt = $conexion->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("s", $cedula);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $response = ['response' => true];
        } else {
            $response = ['response' => false];
        }
        $stmt->close();
    } else {
        $response = ['response' => true, 'error' => "Error en la consulta SQL (verificarCedula): " . $conexion->error];
    }

    return $response;
}

function verificarUsuario(mysqli $conexion, string $usuario): array {
    $sql = "SELECT id, usuario FROM usuarios WHERE usuario = ?";
    $stmt = $conexion->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("s", $usuario);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($idUsuario, $nombreUsuario);
            $stmt->fetch();
            $response = ['response' => true, 'id_usuario' => $idUsuario];
        } else {
            $response = ['response' => false, 'error' => 'Usuario no encontrado.'];
        }
        $stmt->close();
    } else {
        $response = ['response' => false, 'error' => "Error en la consulta SQL (verificarUsuario): " . $conexion->error];
    }

    return $response;
}

function verificarContrasena(mysqli $conexion, string $usuario, string $contrasena): array {
    $sql = "SELECT id_usuario, contrasena FROM usuarios WHERE usuario = ?";
    $stmt = $conexion->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("s", $usuario);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            if (password_verify($contrasena, $row['contrasena'])) {
                $response = ['response' => true, 'id_usuario' => $row['id_usuario']];
            } else {
                $response = ['response' => false, 'error' => 'Contraseña incorrecta.'];
            }
        } else {
            $response = ['response' => false, 'error' => 'Usuario no encontrado.'];
        }

        $stmt->close();
    } else {
        $response = ['response' => false, 'error' => "Error en la consulta SQL (verificarContrasena): " . $conexion->error];
    }

    return $response;
}

if (isset($_POST['cedula'])) {
    $cedula = $_POST['cedula'];
    echo json_encode(verificarCedula($conexion, $cedula), JSON_PRETTY_PRINT);
} elseif (isset($_POST['usuario'])) {
    $usuario = $_POST['usuario'];

    if (isset($_POST['contrasena'])) {
        $contrasena = $_POST['contrasena'];
        echo json_encode(verificarContrasena($conexion, $usuario, $contrasena), JSON_PRETTY_PRINT);
    } else {
        // Si solo se proporciona el usuario, verificamos si existe y obtenemos su ID
        echo json_encode(verificarUsuario($conexion, $usuario), JSON_PRETTY_PRINT);
    }
} else {
    echo json_encode(['response' => false, 'error' => 'Se requiere la cédula o el usuario.'], JSON_PRETTY_PRINT);
}

?>