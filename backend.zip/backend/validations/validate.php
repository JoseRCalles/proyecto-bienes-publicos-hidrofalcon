<?php

session_start();
header('Content-Type: application/json'); 

include '../connect/connect.php';

$response = array('success' => false, 'errors' => array());

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre_usuario = trim($_POST['usuario'] ?? '');
    $contrasena_ingresada = $_POST['contrasena'] ?? '';

    if (empty($nombre_usuario)) {
        $response['errors']['usuario'] = "El nombre de usuario es requerido.";
    }
    if (empty($contrasena_ingresada)) {
        $response['errors']['contrasena'] = "La contraseña es requerida.";
    }

    if (!empty($response['errors'])) {
        echo json_encode($response);
        exit();
    }

    $sql = "SELECT id, contrasena, rango FROM usuarios WHERE usuario = ?"; // <--- CAMBIO AQUÍ
    $stmt = $conexion->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("s", $nombre_usuario);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows == 1) {
            $fila = $resultado->fetch_assoc();
            $hashed_password_from_db = $fila['contrasena'];

            if (password_verify($contrasena_ingresada, $hashed_password_from_db)) {
                // ¡Inicio de sesión exitoso!
                $_SESSION['usuario_id'] = $fila['id'];
                $_SESSION['nombre_usuario'] = $nombre_usuario;
                $_SESSION['rango_id'] = $fila['rango']; // <--- ALMACENA EL RANGO EN LA SESIÓN

                $response['success'] = true;
            } else {
                $response['errors']['contrasena'] = "Usuario o contraseña incorrectos.";
                $response["success"] = false;
            }
        } else {
            $response['errors']['usuario'] = "Usuario o contraseña incorrectos.";
            $response["success"] = false;
        }
        $stmt->close();
    } else {
        $response['errors']['general'] = "Error interno del servidor al procesar la solicitud.";
        $response["success"] = false;
        error_log("Error al preparar la consulta de login: " . $conexion->error);
    }
} else {
    $response['errors']['general'] = "Método de solicitud no válido.";
    $response["success"] = false;
}

$conexion->close();

echo json_encode($response);
exit();
?>