<?php

header('Content-Type: application/json');

require '../connect/connect.php';

// Verificar si la conexión a la base de datos se estableció correctamente
if (!$conexion) {
    echo json_encode(['exists' => false, 'error' => 'Error al conectar a la base de datos.'], JSON_PRETTY_PRINT);
    exit();
}

function verificarExistencia(mysqli $conexion, string $tabla, string $campo, string $valor): bool {
    $sql = "SELECT $campo FROM $tabla WHERE $campo = ?";
    $stmt = $conexion->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("s", $valor);
        $stmt->execute();
        $stmt->store_result();
        $existe = $stmt->num_rows > 0;
        $stmt->close();
        return $existe;
    } else {
        // Error en la consulta SQL
        return false;
    }
}

if (isset($_POST['usuario'])) {
    $usuario = $_POST['usuario'];
    $existeUsuario = verificarExistencia($conexion, 'usuarios', 'usuario', $usuario);
    echo json_encode(['exists' => $existeUsuario], JSON_PRETTY_PRINT);
} elseif (isset($_POST['cedula'])) {
    $cedula = $_POST['cedula'];
    $existeCedula = verificarExistencia($conexion, 'usuarios', 'cedula', $cedula);
    echo json_encode(['exists' => $existeCedula], JSON_PRETTY_PRINT);
} else {
    echo json_encode(['exists' => false, 'error' => 'Se requiere el usuario o la cédula.'], JSON_PRETTY_PRINT);
}

?>